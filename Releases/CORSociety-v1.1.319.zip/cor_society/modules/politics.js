{
  canTriggerIfUnavailable: true,
  checkType: 'general',
  checkAndAct() {},
  methods: {
    _mixinCorSocietyPolitics() {
      if (!window.corSociety) {
        return
      }
      if (window.corSociety._mixinCorSocietyPoliticsVersion === '1.1.319') {
        return
      }
      Object.assign(window.corSociety, {
        ensureRomeState(society) {
                  society.rome = society.rome || {}
                  let rome = society.rome
                  rome.government = rome.government || 'republic'
                  rome.rulerHouseId = rome.rulerHouseId || ''
                  rome.rulerCharacterId = rome.rulerCharacterId || ''
                  rome.successionLaw = rome.successionLaw || 'designation'
                  rome.dictatorHouseId = rome.dictatorHouseId || ''
                  rome.dictatorCharacterId = rome.dictatorCharacterId || ''
                  rome.dictatorTermEnd = rome.dictatorTermEnd || ''
                  rome.everHadEmperor = !!rome.everHadEmperor
                  rome.successionPressure = parseFloat(rome.successionPressure || 0)
                  rome.wars = rome.wars || []
                  rome.appointments = rome.appointments || {}
                  society.captives = society.captives || []
                  society.playerPolitics = society.playerPolitics || {}
                  let pp = society.playerPolitics
                  pp.auctoritas = parseFloat(pp.auctoritas || 0)
                  pp.faction = pp.faction || []
                  pp.wasDictator = !!pp.wasDictator
                  pp.lastDefendMonth = pp.lastDefendMonth || ''
                  return rome
                },
        playerPoliticsHouse(society, state) {
                  let currentId = this.currentCharacterId(state)
                  let character = state.characters && state.characters[currentId]
                  if (!character) {
                    return false
                  }
                  character.id = character.id || currentId
                  let houseId = this.houseIdForCharacter(character, state, society)
                  return houseId && society.houses[houseId] ? society.houses[houseId] : false
                },
        playerIsSenatorial(state) {
                  state = state || daapi.getState()
                  if (state.current && (state.current.flagIsSenetorialClass || state.current.flagIsSenatorialClass)) {
                    return true
                  }
                  let stratum = this.playerStratum ? this.playerStratum(state) : ''
                  return stratum === 'senatorial'
                },
        playerSenateOfficeCount(state) {
                  let senate = (state.current && state.current.senate) || {}
                  let currentId = String(this.currentCharacterId(state))
                  let count = 0
                  for (let office in senate) {
                    if (senate.hasOwnProperty(office) && (senate[office] || []).map(String).indexOf(currentId) >= 0) {
                      count += 1
                    }
                  }
                  return count
                },
        playerAuctoritasScore(society, state) {
                  let pp = society.playerPolitics || {}
                  let current = state.current || {}
                  let prestige = parseFloat(current.prestige || 0)
                  let influence = parseFloat(current.influence || 0)
                  let faction = (pp.faction || []).filter((id) => society.houses[id]).length
                  let offices = this.playerSenateOfficeCount(state)
                  let house = this.playerPoliticsHouse(society, state)
                  let propertyValue = house && this.housePropertyValue ? this.housePropertyValue(house) : 0
                  return Math.round(prestige / 40 + influence / 120 + faction * 8 + offices * 16 + propertyValue / 800 + parseFloat(pp.auctoritas || 0))
                },
        playerIsDictator(society, state) {
                  let rome = this.ensureRomeState(society)
                  let house = this.playerPoliticsHouse(society, state)
                  return !!(rome.government === 'dictatorship' && house && String(rome.dictatorHouseId) === String(house.id))
                },
        playerIsEmperor(society, state) {
                  let rome = this.ensureRomeState(society)
                  let house = this.playerPoliticsHouse(society, state)
                  return !!(rome.government === 'empire' && house && String(rome.rulerHouseId) === String(house.id))
                },
        governmentLabel(rome) {
                  if (rome.government === 'dictatorship') return 'Dictatorship'
                  if (rome.government === 'empire') return 'Empire'
                  return 'Republic'
                },
        imperatorIcon() {
                  try {
                    return daapi.requireImage('/cor_society/assets/aquila.svg')
                  } catch (err) {
                    return this.affairIcon('senator')
                  }
                },
        playerPoliticalRank(society, state) {
                  if (this.playerIsEmperor(society, state)) return 'emperor'
                  if (this.playerIsDictator(society, state)) return 'dictator'
                  return ''
                },
        playerPoliticalTitle(society, state) {
                  let rank = this.playerPoliticalRank(society, state)
                  if (rank === 'emperor') return 'Imperator'
                  if (rank === 'dictator') return 'Dictator'
                  return ''
                },
        politicalPowerBonus(society, state) {
                  // Real, ongoing mechanical edge for holding supreme office. Emperor > Dictator.
                  let rank = this.playerPoliticalRank(society, state)
                  if (rank === 'emperor') return 0.28
                  if (rank === 'dictator') return 0.15
                  return 0
                },
        politicsAction(args) {
                  args = args || {}
                  let map = {
                    recruitFactionHouse: 'recruitFactionHouse',
                    pressLandClaim: 'pressLandClaim',
                    raidProperty: 'raidProperty',
                    fortifyProperty: 'fortifyProperty',
                    startAbduction: 'startAbduction',
                    ransomCaptive: 'ransomCaptive',
                    releaseCaptive: 'releaseCaptive',
                    demandHookFromCaptive: 'demandHookFromCaptive',
                    seekDictatorship: 'seekDictatorship',
                    layDownDictatorship: 'layDownDictatorship',
                    attemptEmpire: 'attemptEmpire',
                    appointGovernor: 'appointGovernor',
                    declareWar: 'declareWar',
                    holdGames: 'holdGames',
                    defendSuccession: 'defendSuccession',
                    openFactionRecruit: 'openFactionRecruit',
                    openRivalPolitics: 'openRivalPolitics',
                    openCaptives: 'openCaptives',
                    openEmperorActions: 'openEmperorActions',
                    openAppointGovernor: 'openAppointGovernor',
                    openDeclareWar: 'openDeclareWar',
                    openHousePolitics: 'openHousePolitics'
                  }
                  let method = map[args.action]
                  if (method && typeof this[method] === 'function') {
                    return this[method](args)
                  }
                  return this.openPolitics()
                },
        politicsButton(action, text, icon, context, extra) {
                  let option = {
                    text,
                    icons: [this.affairIcon(icon || 'senator')],
                    action: {
                      event: this.event,
                      method: 'politicsAction',
                      context: Object.assign({ action }, context || {})
                    }
                  }
                  return Object.assign(option, extra || {})
                },
        openPolitics() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  this.save(society)
                  let pp = society.playerPolitics
                  let house = this.playerPoliticsHouse(society, state)
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  let factionSize = (pp.faction || []).filter((id) => society.houses[id]).length
                  let offices = this.playerSenateOfficeCount(state)
                  let isSenatorial = this.playerIsSenatorial(state)
                  let isDictator = this.playerIsDictator(society, state)
                  let isEmperor = this.playerIsEmperor(society, state)
                  let rulerHouse = rome.rulerHouseId && society.houses[rome.rulerHouseId]
                  let summary = [
                    this.summaryOption('Government', this.governmentLabel(rome), [this.affairIcon('senator')], 'The current form of Roman government.'),
                    this.summaryOption('Ruler', isEmperor ? 'You — Imperator' : isDictator ? 'You — Dictator' : (rulerHouse ? rulerHouse.name : (rome.government === 'republic' ? 'the Senate' : 'none')), [isEmperor ? this.imperatorIcon() : this.affairIcon('prestige')], 'Who currently holds supreme power.'),
                    this.summaryOption('Succession', rome.government === 'empire' ? (rome.successionLaw === 'wealth' ? 'By wealth' : rome.successionLaw === 'power' ? 'By power' : 'By designation/adoption') : 'n/a', [this.affairIcon('familyTree')], 'How imperial succession is decided. Rivals may push to change it.'),
                    this.summaryOption('Auctoritas', auctoritas, [this.affairIcon('influence')], 'Your political weight: prestige, influence, faction, offices, property.'),
                    this.summaryOption('Faction', factionSize + ' houses', [this.affairIcon('support')], 'Houses backing your ambitions.'),
                    this.summaryOption('Senate offices', offices, [this.affairIcon('senator')], 'Magistracies you currently hold (cursus honorum).')
                  ]
                  let options = []
                  options.push(this.politicsButton('openFactionRecruit', 'Build your faction', 'support'))
                  options.push(this.politicsButton('openRivalPolitics', 'Pressure rival houses (feuds, abduction)', 'rivalry'))
                  if ((society.captives || []).some((c) => c && c.captorIsPlayer)) {
                    options.push(this.politicsButton('openCaptives', 'Held captives (' + (society.captives || []).filter((c) => c && c.captorIsPlayer).length + ')', 'scandal'))
                  }
                  if (rome.government === 'republic') {
                    let gate = this.dictatorshipGate(society, state)
                    options.push(this.politicsButton('seekDictatorship', 'Seek the Dictatorship' + (gate.ready ? '' : ' (locked)'), 'prestige', {}, gate.ready ? {} : { disabled: true, showDisabledWithTooltip: true, tooltip: gate.reason }))
                  }
                  if (isDictator) {
                    let remaining = this.monthsUntil(rome.dictatorTermEnd, state)
                    options.push(this.politicsButton('layDownDictatorship', 'Lay down the dictatorship (honourable)', 'prestige'))
                    let egate = this.empireGate(society, state)
                    options.push(this.politicsButton('attemptEmpire', 'Make yourself Emperor' + (egate.ready ? '' : ' (locked)'), 'senator', {}, egate.ready ? {} : { disabled: true, showDisabledWithTooltip: true, tooltip: egate.reason }))
                    summary.push(this.summaryOption('Dictator term', remaining > 0 ? remaining + ' months left' : 'expiring', [this.affairIcon('death')], 'The dictatorship is temporary; the Senate will force you to lay it down when it ends.'))
                  }
                  if (isEmperor) {
                    options.push(this.politicsButton('openEmperorActions', 'Imperial powers', 'senator'))
                  }
                  options = options.filter(Boolean)
                  options.push({ text: 'Back', action: { event: this.event, method: 'openHub' } })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Senate & Politics',
                    message: rome.government === 'republic'
                      ? 'The Republic stands. Climb the cursus honorum, build a faction, and — in a crisis — you may be named Dictator. Few dictators ever become Emperor.'
                      : rome.government === 'dictatorship'
                        ? 'You wield extraordinary powers for a limited term. Lay them down with honour, or risk everything to seize the purple.'
                        : 'The Empire endures. Defend your succession and project power across the provinces.',
                    societySummaryOptions: summary.filter(Boolean),
                    image: isEmperor ? this.imperatorIcon() : this.affairIcon('senator'),
                    options
                  })
                },
        monthsUntil(monthKey, state) {
                  if (!monthKey) {
                    return 0
                  }
                  return Math.max(0, this.monthIndex(monthKey) - this.monthIndex(this.monthKey(state || daapi.getState())))
                },
        politicsRivalHouses(society, state) {
                  let playerHouse = this.playerPoliticsHouse(society, state)
                  return this.sortedHouses(society).filter((house) => {
                    return house && house.id && (!playerHouse || String(house.id) !== String(playerHouse.id)) && !house.isPlayerHouse
                  })
                },
        openFactionRecruit() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let pp = this.ensureRomeState(society).government ? society.playerPolitics : society.playerPolitics
                  let cash = parseFloat((state.current || {}).cash || 0)
                  let houses = this.politicsRivalHouses(society, state).slice(0, 12)
                  let options = houses.map((house) => {
                    let inFaction = (pp.faction || []).indexOf(house.id) >= 0
                    let cost = Math.max(20, Math.round((this.actionCost(house, 'dinner') || 40) * 1.4))
                    return this.politicsButton('recruitFactionHouse', (inFaction ? '✓ ' : '') + house.name + ' (relation ' + this.signed(house.relation || 0) + ', cost ' + cost + ')', 'support', { houseId: house.id }, inFaction || cash < cost ? { disabled: true, showDisabledWithTooltip: true, tooltip: inFaction ? 'Already in your faction.' : 'Not enough cash (' + cost + ').' } : {})
                  })
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Build your faction',
                    message: 'Win houses to your cause with patronage and favours. Friendly houses are easier to recruit. A strong faction is required to be named Dictator.',
                    image: this.affairIcon('support'),
                    options
                  })
                },
        recruitFactionHouse({ houseId } = {}) {
                  this.withHouse(houseId, (society, house) => {
                    let state = daapi.getState()
                    let pp = this.ensureRomeState(society).government ? society.playerPolitics : society.playerPolitics
                    if ((pp.faction || []).indexOf(houseId) >= 0) {
                      return
                    }
                    let cost = Math.max(20, Math.round((this.actionCost(house, 'dinner') || 40) * 1.4))
                    this.applyStats({ cash: -cost, influence: -8 })
                    let chance = this.clamp(0.3 + (house.relation || 0) / 160 + (house.favor || 0) * 0.08 + this.politicalPowerBonus(society, state), 0.05, 0.96)
                    if (Math.random() < chance) {
                      pp.faction = pp.faction || []
                      pp.faction.push(houseId)
                      house.relation = this.clamp((house.relation || 0) + 12, -100, 100)
                      pp.auctoritas = parseFloat(pp.auctoritas || 0) + 4
                      this.log(society, house.name + ' joins your political faction.', 'support', houseId)
                    } else {
                      house.relation = this.clamp((house.relation || 0) - 4, -100, 100)
                      this.log(society, house.name + ' declines to join your faction for now.', 'support', houseId)
                    }
                  })
                  this.openFactionRecruit()
                },
        openRivalPolitics() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  this.ensureRomeState(society)
                  let houses = this.politicsRivalHouses(society, state).slice(0, 12)
                  let options = houses.map((house) => {
                    return this.politicsButton('openHousePolitics', house.name + ' (power ' + Math.round(house.power || 0) + ', relation ' + this.signed(house.relation || 0) + ')', 'rivalry', { houseId: house.id })
                  })
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Pressure rival houses',
                    message: 'Choose a house to feud with over property, or to target for abduction. Proscriptions and seizures are legal weapons between powerful families.',
                    image: this.affairIcon('rivalry'),
                    options
                  })
                },
        openHousePolitics({ houseId } = {}) {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let house = society.houses[houseId]
                  if (!house) {
                    this.openRivalPolitics()
                    return
                  }
                  let cash = parseFloat((state.current || {}).cash || 0)
                  let claimCost = Math.max(30, Math.round((house.power || 40) * 0.8))
                  let raidCost = Math.max(15, Math.round(claimCost * 0.5))
                  let members = (house.notableIds || house.memberIds || []).map((id) => state.characters && state.characters[id]).filter((c) => c && !c.isDead)
                  let target = members[0]
                  let options = []
                  options.push(this.politicsButton('pressLandClaim', 'Press a land claim (seize property, cost ' + claimCost + ' infl.)', 'coins', { houseId }))
                  options.push(this.politicsButton('raidProperty', 'Raid / blockade their estates (cost ' + raidCost + ')', 'trade', { houseId }))
                  if (target) {
                    options.push(this.politicsButton('startAbduction', 'Abduct ' + this.characterName({ ...target, id: target.id || (house.notableIds || [])[0] }, state) + ' for ransom', 'scandal', { houseId, characterId: target.id || (house.notableIds || [])[0] }))
                  }
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openRivalPolitics' } } })
                  this.pushModal({
                    societyMenu: true,
                    title: house.name,
                    message: 'Power ' + Math.round(house.power || 0) + ', wealth ' + Math.round(house.wealth || 0) + ', relation ' + this.signed(house.relation || 0) + '.',
                    image: this.houseCrestIcon ? this.houseCrestIcon(society, house) : this.affairIcon('rivalry'),
                    options
                  })
                },
        pressLandClaim({ houseId } = {}) {
                  let resultText = ''
                  this.withHouse(houseId, (society, house) => {
                    let state = daapi.getState()
                    this.ensureRomeState(society)
                    let playerHouse = this.playerPoliticsHouse(society, state)
                    let cost = Math.max(30, Math.round((house.power || 40) * 0.8))
                    this.applyStats({ influence: -cost })
                    let myPower = (playerHouse && playerHouse.power) || 40
                    let theirPower = house.power || 40
                    let myStew = (playerHouse && this.houseHouseholdStewardship) ? this.houseHouseholdStewardship(playerHouse, state) : 30
                    let chance = this.clamp(0.42 + (myPower - theirPower) / 240 + myStew / 600 + this.politicalPowerBonus(society, state) - (house.fortifiedUntil && this.monthKeyReached(house.fortifiedUntil, state) === false ? 0.2 : 0), 0.08, 0.95)
                    let place = this.romanPlace('estate')
                    if (Math.random() < chance) {
                      let seized = Math.max(20, Math.round((house.wealth || 200) * this.randomInt(8, 18) / 100))
                      house.wealth = Math.max(0, Math.round((house.wealth || 0) - seized))
                      if (house.ai) house.ai.cash = Math.max(0, Math.round((house.ai.cash || 0) - seized * 0.4))
                      this.applyStats({ cash: Math.round(seized * 0.5), prestige: 6 })
                      house.relation = this.clamp((house.relation || 0) - 22, -100, 100)
                      house.heat = (house.heat || 0) + 4
                      house.rivalry = true
                      resultText = 'You press the courts and your clients and seize ' + place + ' from ' + house.name + ' (worth ' + seized + ').'
                      this.log(society, resultText, 'rivalry', houseId)
                    } else {
                      this.applyStats({ prestige: -6 })
                      house.relation = this.clamp((house.relation || 0) - 10, -100, 100)
                      house.heat = (house.heat || 0) + 2
                      resultText = 'Your land claim against ' + house.name + ' over ' + place + ' fails in the courts; you lose face.'
                      this.log(society, resultText, 'rivalry', houseId)
                    }
                  })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Land claim',
                    message: resultText || 'Nothing happened.',
                    image: this.affairIcon('coins'),
                    options: [{ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openHousePolitics', houseId } } }]
                  })
                },
        raidProperty({ houseId } = {}) {
                  let resultText = ''
                  this.withHouse(houseId, (society, house) => {
                    let state = daapi.getState()
                    let cost = Math.max(15, Math.round((house.power || 40) * 0.4))
                    this.applyStats({ cash: -cost })
                    house.ai = house.ai || {}
                    house.ai.modifiers = house.ai.modifiers || {}
                    house.ai.modifiers.revenue = house.ai.modifiers.revenue || []
                    house.ai.modifiers.revenue.push({ factor: 0.78, until: this.futureMonthKey(this.randomInt(2, 4)) })
                    house.relation = this.clamp((house.relation || 0) - 8, -100, 100)
                    house.heat = (house.heat || 0) + 2
                    let place = this.romanPlace('landmark')
                    resultText = 'Your clients blockade ' + house.name + "'s trade through " + place + '; their revenue drops for a few months.'
                    this.log(society, resultText, 'trade', houseId)
                  })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Raid / blockade',
                    message: resultText || 'Nothing happened.',
                    image: this.affairIcon('trade'),
                    options: [{ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openHousePolitics', houseId } } }]
                  })
                },
        fortifyProperty() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let house = this.playerPoliticsHouse(society, state)
                  if (house) {
                    let cost = 60
                    this.applyStats({ cash: -cost })
                    house.fortifiedUntil = this.futureMonthKey(6)
                    this.log(society, 'You fortify your estates and clientela against rival seizures.', 'support', house.id)
                  }
                  this.save(society)
                  this.openPolitics()
                },
        startAbduction({ houseId, characterId } = {}) {
                  let resultText = ''
                  this.withHouse(houseId, (society, house) => {
                    let state = daapi.getState()
                    this.ensureRomeState(society)
                    let character = state.characters && state.characters[characterId]
                    if (!character || character.isDead) {
                      resultText = 'There is no suitable target to abduct.'
                      return
                    }
                    character.id = character.id || characterId
                    let cost = 40
                    this.applyStats({ influence: -cost })
                    let exposeChance = this.clamp(0.3 - (house.heat || 0) * 0.01, 0.12, 0.5)
                    if (Math.random() < exposeChance) {
                      this.applyStats({ prestige: -10 })
                      house.relation = this.clamp((house.relation || 0) - 20, -100, 100)
                      house.heat = (house.heat || 0) + 5
                      resultText = 'Your abduction plot against ' + this.characterName(character, state) + ' is exposed! Scandal stains your name.'
                      this.log(society, resultText, 'scandal', houseId)
                      return
                    }
                    society.captives = society.captives || []
                    society.captives.push({
                      id: 'cap_' + characterId + '_' + this.monthKey(state),
                      characterId,
                      houseId,
                      captorIsPlayer: true,
                      until: this.futureMonthKey(this.randomInt(5, 9)),
                      name: this.characterName(character, state)
                    })
                    house.relation = this.clamp((house.relation || 0) - 14, -100, 100)
                    house.heat = (house.heat || 0) + 3
                    resultText = 'You spirit ' + this.characterName(character, state) + ' away to a safe house near ' + this.romanPlace('district') + '. You can now ransom them.'
                    this.log(society, resultText, 'scandal', houseId)
                  })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Abduction',
                    message: resultText || 'Nothing happened.',
                    image: this.affairIcon('scandal'),
                    options: [{ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openHousePolitics', houseId } } }]
                  })
                },
        openCaptives() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  this.ensureRomeState(society)
                  let captives = (society.captives || []).filter((c) => c && c.captorIsPlayer)
                  let options = captives.map((captive) => {
                    let house = society.houses[captive.houseId]
                    return {
                      text: captive.name + (house ? ' of ' + house.name : '') + ' (until ' + (captive.until || '?') + ')',
                      icons: [this.affairIcon('scandal')],
                      tooltip: 'Ransom for cash, demand a future favour (hook), or release for goodwill.',
                      action: { event: this.event, method: 'politicsAction', context: { action: 'ransomCaptive', captiveId: captive.id } }
                    }
                  })
                  captives.forEach((captive) => {
                    options.push(this.politicsButton('demandHookFromCaptive', 'Demand a favour from ' + (society.houses[captive.houseId] ? society.houses[captive.houseId].name : 'the house') + ' for ' + captive.name, 'support', { captiveId: captive.id }))
                    options.push(this.politicsButton('releaseCaptive', 'Release ' + captive.name + ' for goodwill', 'gift', { captiveId: captive.id }))
                  })
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Held captives',
                    message: captives.length ? 'Each captive can be ransomed once for leverage.' : 'You hold no captives.',
                    image: this.affairIcon('scandal'),
                    options
                  })
                },
        findCaptive(society, captiveId) {
                  return (society.captives || []).find((c) => c && c.id === captiveId)
                },
        ransomCaptive({ captiveId } = {}) {
                  let society = this.loadForAction()
                  this.ensureRomeState(society)
                  let captive = this.findCaptive(society, captiveId)
                  if (captive) {
                    let house = society.houses[captive.houseId]
                    let ransom = house ? Math.max(40, Math.round((house.wealth || 200) * 0.12)) : 80
                    if (house) {
                      house.wealth = Math.max(0, Math.round((house.wealth || 0) - ransom))
                      house.relation = this.clamp((house.relation || 0) - 6, -100, 100)
                    }
                    this.applyStats({ cash: ransom })
                    this.log(society, 'You ransom ' + captive.name + ' back to ' + (house ? house.name : 'their house') + ' for ' + ransom + ' cash.', 'coins', captive.houseId)
                    society.captives = (society.captives || []).filter((c) => c && c.id !== captiveId)
                  }
                  this.save(society)
                  this.openCaptives()
                },
        demandHookFromCaptive({ captiveId } = {}) {
                  let society = this.loadForAction()
                  this.ensureRomeState(society)
                  let captive = this.findCaptive(society, captiveId)
                  if (captive) {
                    let house = society.houses[captive.houseId]
                    if (house) {
                      house.playerHookUntil = this.futureMonthKey(24)
                      house.relation = this.clamp((house.relation || 0) - 4, -100, 100)
                      if ((society.playerPolitics.faction || []).indexOf(house.id) < 0 && Math.random() < 0.5) {
                        society.playerPolitics.faction.push(house.id)
                      }
                      this.log(society, 'You extract a binding favour from ' + house.name + ' in exchange for ' + captive.name + '.', 'support', captive.houseId)
                    }
                    society.captives = (society.captives || []).filter((c) => c && c.id !== captiveId)
                  }
                  this.save(society)
                  this.openCaptives()
                },
        releaseCaptive({ captiveId } = {}) {
                  let society = this.loadForAction()
                  this.ensureRomeState(society)
                  let captive = this.findCaptive(society, captiveId)
                  if (captive) {
                    let house = society.houses[captive.houseId]
                    if (house) {
                      house.relation = this.clamp((house.relation || 0) + 18, -100, 100)
                      house.heat = Math.max(0, (house.heat || 0) - 2)
                    }
                    this.applyStats({ prestige: 4 })
                    this.log(society, 'You release ' + captive.name + ' unharmed, earning goodwill.', 'gift', captive.houseId)
                    society.captives = (society.captives || []).filter((c) => c && c.id !== captiveId)
                  }
                  this.save(society)
                  this.openCaptives()
                },
        dictatorshipGate(society, state) {
                  let rome = this.ensureRomeState(society)
                  if (rome.government !== 'republic') {
                    return { ready: false, reason: 'Rome is not a Republic right now.' }
                  }
                  if (!this.playerIsSenatorial(state)) {
                    return { ready: false, reason: 'You must reach the senatorial order (Senate seat) first.' }
                  }
                  let faction = (society.playerPolitics.faction || []).filter((id) => society.houses[id]).length
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  if (faction < 3) {
                    return { ready: false, reason: 'You need at least 3 houses in your faction (have ' + faction + ').' }
                  }
                  if (auctoritas < 70) {
                    return { ready: false, reason: 'You need more auctoritas (have ' + auctoritas + ', need 70).' }
                  }
                  return { ready: true, reason: '' }
                },
        seekDictatorship() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let gate = this.dictatorshipGate(society, state)
                  if (!gate.ready) {
                    this.save(society)
                    this.pushModal({ societyMenu: true, title: 'Dictatorship', message: gate.reason, image: this.affairIcon('senator'), options: [{ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } }] })
                    return
                  }
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  this.applyStats({ influence: -60 })
                  let chance = this.clamp(0.25 + (auctoritas - 70) / 240, 0.15, 0.7)
                  let house = this.playerPoliticsHouse(society, state)
                  let message = ''
                  if (Math.random() < chance) {
                    rome.government = 'dictatorship'
                    rome.dictatorHouseId = house ? house.id : ''
                    rome.dictatorCharacterId = this.currentCharacterId(state)
                    rome.dictatorTermEnd = this.futureMonthKey(6)
                    society.playerPolitics.wasDictator = true
                    society.playerPolitics.auctoritas = parseFloat(society.playerPolitics.auctoritas || 0) + 20
                    this.applyStats({ prestige: 30 })
                    this.politicsRivalHouses(society, state).slice(0, 8).forEach((h) => {
                      if ((society.playerPolitics.faction || []).indexOf(h.id) < 0) {
                        h.heat = (h.heat || 0) + 2
                        h.relation = this.clamp((h.relation || 0) - 6, -100, 100)
                      }
                    })
                    message = 'In the crisis, the Senate names you DICTATOR for a six-month term, with a master of horse at your side. Rival houses watch with alarm. Few who hold this office ever go further.'
                    this.log(society, 'You are named Dictator of Rome.', 'prestige')
                  } else {
                    this.applyStats({ prestige: -20 })
                    message = 'The Senate refuses to name you Dictator; the optimates rally against you and your standing suffers.'
                    this.log(society, 'Your bid for the dictatorship fails in the Senate.', 'rivalry')
                  }
                  this.save(society)
                  this.pushModal({ societyMenu: true, title: 'The Dictatorship', message, image: this.affairIcon('senator'), options: [{ text: 'Continue', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } }] })
                },
        layDownDictatorship() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  if (this.playerIsDictator(society, state)) {
                    rome.government = 'republic'
                    rome.dictatorHouseId = ''
                    rome.dictatorCharacterId = ''
                    rome.dictatorTermEnd = ''
                    this.applyStats({ prestige: 25, influence: 15 })
                    society.playerPolitics.auctoritas = parseFloat(society.playerPolitics.auctoritas || 0) + 10
                    this.log(society, 'Like Cincinnatus, you lay down the dictatorship and restore the Republic. Your honour soars.', 'prestige')
                  }
                  this.save(society)
                  this.pushModal({ societyMenu: true, title: 'Dictatorship laid down', message: 'You return supreme power to the Senate and the people of Rome. They will remember it.', image: this.affairIcon('prestige'), options: [{ text: 'Continue', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } }] })
                },
        empireGate(society, state) {
                  let rome = this.ensureRomeState(society)
                  if (!this.playerIsDictator(society, state)) {
                    return { ready: false, reason: 'Only a sitting Dictator can make the final bid for the purple. (The first Emperor must first be Dictator.)' }
                  }
                  let faction = (society.playerPolitics.faction || []).filter((id) => society.houses[id]).length
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  let offices = this.playerSenateOfficeCount(state)
                  let cash = parseFloat((state.current || {}).cash || 0)
                  if (faction < 5) return { ready: false, reason: 'You need at least 5 houses in your faction (have ' + faction + ').' }
                  if (auctoritas < 140) return { ready: false, reason: 'You need overwhelming auctoritas (have ' + auctoritas + ', need 140).' }
                  if (offices < 1) return { ready: false, reason: 'You must hold a Senate office to command imperium.' }
                  if (cash < 300) return { ready: false, reason: 'You need a war chest of at least 300 cash for donatives.' }
                  return { ready: true, reason: '' }
                },
        attemptEmpire() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let gate = this.empireGate(society, state)
                  if (!gate.ready) {
                    this.save(society)
                    this.pushModal({ societyMenu: true, title: 'The purple', message: gate.reason, image: this.affairIcon('senator'), options: [{ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } }] })
                    return
                  }
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  this.applyStats({ cash: -300, influence: -80 })
                  // Hard multi-stage bid; each stage can fail. Many attempts fail by design.
                  let base = this.clamp(0.18 + (auctoritas - 140) / 400, 0.1, 0.55)
                  let stages = [
                    { name: 'Senate vote of extraordinary powers', p: base + 0.05 },
                    { name: 'Army and Praetorian acclamation', p: base },
                    { name: 'Optimates and rival claimants suppressed', p: base - 0.03 }
                  ]
                  let failedStage = ''
                  for (let i = 0; i < stages.length; i++) {
                    if (Math.random() > this.clamp(stages[i].p, 0.05, 0.7)) {
                      failedStage = stages[i].name
                      break
                    }
                  }
                  let house = this.playerPoliticsHouse(society, state)
                  let message = ''
                  if (!failedStage) {
                    rome.government = 'empire'
                    rome.rulerHouseId = house ? house.id : ''
                    rome.rulerCharacterId = this.currentCharacterId(state)
                    rome.everHadEmperor = true
                    rome.successionLaw = 'designation'
                    rome.dictatorHouseId = ''
                    rome.dictatorTermEnd = ''
                    rome.successionPressure = 0
                    this.applyStats({ prestige: 80, influence: 60 })
                    this.politicsRivalHouses(society, state).forEach((h) => {
                      let friendly = (society.playerPolitics.faction || []).indexOf(h.id) >= 0
                      h.relation = this.clamp((h.relation || 0) + (friendly ? 10 : -8), -100, 100)
                      if (!friendly) h.heat = (h.heat || 0) + 2
                    })
                    message = 'After Dictatorship comes the purple. The Senate, army, and people acclaim you IMPERATOR — and the eagle of Rome (SPQR) is raised in your name. Rome becomes an Empire. War-time edicts and your imperial powers now ripple across every house, and the imperial fisc pays you each month.'
                    this.log(society, 'You become Imperator — the first Emperor of Rome.', 'prestige')
                  } else {
                    // Failure branches — costly, sometimes catastrophic.
                    let roll = Math.random()
                    if (roll < 0.45) {
                      rome.government = 'republic'
                      rome.dictatorHouseId = ''
                      rome.dictatorTermEnd = ''
                      this.applyStats({ prestige: -40 })
                      message = 'Your bid collapses at: ' + failedStage + '. You are forced to lay down all power and retreat to private life. The Republic endures.'
                      this.log(society, 'Your bid for the purple fails (' + failedStage + '); you are forced from power.', 'rivalry')
                    } else if (roll < 0.8) {
                      rome.government = 'republic'
                      rome.dictatorHouseId = ''
                      rome.dictatorTermEnd = ''
                      this.applyStats({ prestige: -50, cash: -Math.round(parseFloat((state.current || {}).cash || 0) * 0.4), influence: -60 })
                      if (house) house.heat = (house.heat || 0) + 6
                      message = 'You fail at: ' + failedStage + '. You are proscribed — your property plundered and your name dragged through the courts.'
                      this.log(society, 'Proscription! Your bid for the purple ends in ruin.', 'scandal')
                    } else {
                      rome.government = 'republic'
                      rome.dictatorHouseId = ''
                      rome.dictatorTermEnd = ''
                      this.applyStats({ prestige: -70, influence: -100 })
                      rome.wars = rome.wars || []
                      this.politicsRivalHouses(society, state).slice(0, 6).forEach((h) => {
                        h.heat = (h.heat || 0) + 5
                        h.relation = this.clamp((h.relation || 0) - 20, -100, 100)
                        h.rivalry = true
                      })
                      message = 'Your coup fails at: ' + failedStage + '. Rome plunges into CIVIL WAR; the great houses take up arms and your faction is shattered.'
                      this.log(society, 'Civil war erupts after your failed bid for the purple.', 'rivalry')
                    }
                  }
                  this.save(society)
                  this.pushModal({ societyMenu: true, title: failedStage ? 'The bid for the purple' : 'Imperator', message, image: failedStage ? this.affairIcon('senator') : this.imperatorIcon(), options: [{ text: 'Continue', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } }] })
                },
        openEmperorActions() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  if (!this.playerIsEmperor(society, state)) {
                    this.openPolitics()
                    return
                  }
                  let options = [
                    this.politicsButton('openAppointGovernor', 'Appoint a provincial governor', 'senator'),
                    this.politicsButton('openDeclareWar', 'Declare war on a house', 'rivalry'),
                    this.politicsButton('holdGames', 'Hold games and donatives (defend your position)', 'prestige'),
                    this.politicsButton('defendSuccession', 'Defend the succession (pressure ' + Math.round(rome.successionPressure || 0) + '%)', 'familyTree')
                  ]
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openPolitics' } } })
                  this.pushModal({
                    societyMenu: true,
                    title: 'Imperator — Imperial powers',
                    message: 'As Imperator, under the eagle of Rome (SPQR), you command appointments, war, and the loyalty of Rome, and the imperial fisc fills your treasury each month. Rivals will push to change the succession to favour the wealthiest or strongest house — hold them off.',
                    image: this.imperatorIcon(),
                    options
                  })
                },
        openAppointGovernor() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let houses = this.politicsRivalHouses(society, state).slice(0, 10)
                  let regions = this.romanRegions || ['Latium']
                  let options = houses.map((house, index) => {
                    let region = regions[index % regions.length]
                    return this.politicsButton('appointGovernor', 'Make ' + house.name + ' governor of ' + region, 'senator', { houseId: house.id, region })
                  })
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openEmperorActions' } } })
                  this.pushModal({ societyMenu: true, title: 'Appoint a governor', message: 'Reward a house with a province. It strengthens their loyalty and revenue — and your patronage network.', image: this.affairIcon('senator'), options })
                },
        appointGovernor({ houseId, region } = {}) {
                  this.withHouse(houseId, (society, house) => {
                    let rome = this.ensureRomeState(society)
                    rome.appointments[houseId] = { region: region || 'a province', until: this.futureMonthKey(36) }
                    house.relation = this.clamp((house.relation || 0) + 20, -100, 100)
                    house.wealth = (house.wealth || 0) + 120
                    if ((society.playerPolitics.faction || []).indexOf(houseId) < 0) {
                      society.playerPolitics.faction.push(houseId)
                    }
                    this.log(society, 'You appoint ' + house.name + ' as governor of ' + (region || 'a province') + '.', 'senator', houseId)
                  })
                  this.openEmperorActions()
                },
        openDeclareWar() {
                  let society = this.ensure()
                  let state = daapi.getState()
                  let houses = this.politicsRivalHouses(society, state).slice(0, 10)
                  let options = houses.map((house) => {
                    return this.politicsButton('declareWar', 'War on ' + house.name + ' (power ' + Math.round(house.power || 0) + ')', 'rivalry', { houseId: house.id })
                  })
                  options.push({ text: 'Back', action: { event: this.event, method: 'politicsAction', context: { action: 'openEmperorActions' } } })
                  this.pushModal({ societyMenu: true, title: 'Declare war', message: 'Imperial war affects all of Rome: the targeted house and its allies suffer, and war-time notices spread across the houses.', image: this.affairIcon('rivalry'), options })
                },
        declareWar({ houseId } = {}) {
                  this.withHouse(houseId, (society, house) => {
                    let state = daapi.getState()
                    let rome = this.ensureRomeState(society)
                    rome.wars.push({ houseId, startMonth: this.monthKey(state), endMonth: this.futureMonthKey(this.randomInt(3, 6)) })
                    house.relation = this.clamp((house.relation || 0) - 40, -100, 100)
                    house.heat = (house.heat || 0) + 8
                    house.rivalry = true
                    house.ai = house.ai || {}
                    house.ai.modifiers = house.ai.modifiers || {}
                    house.ai.modifiers.revenue = house.ai.modifiers.revenue || []
                    house.ai.modifiers.revenue.push({ factor: 0.6, until: this.futureMonthKey(5) })
                    this.applyStats({ influence: -40 })
                    this.politicsRivalHouses(society, state).slice(0, 10).forEach((h) => {
                      if (String(h.id) !== String(houseId)) {
                        h.stability = this.clamp((h.stability || 50) - 4, 0, 100)
                      }
                    })
                    this.log(society, 'Imperial war is declared on ' + house.name + '. Levies march near ' + this.romanPlace('region') + '; the houses brace for war.', 'rivalry', houseId)
                  })
                  this.openEmperorActions()
                },
        holdGames() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let cost = 150
                  this.applyStats({ cash: -cost, prestige: 20 })
                  society.playerPolitics.auctoritas = parseFloat(society.playerPolitics.auctoritas || 0) + 12
                  rome.successionPressure = Math.max(0, parseFloat(rome.successionPressure || 0) - 25)
                  this.sortedHouses(society).slice(0, 12).forEach((h) => {
                    if (!h.isPlayerHouse) h.relation = this.clamp((h.relation || 0) + 5, -100, 100)
                  })
                  this.log(society, 'You stage lavish games and donatives at ' + this.romanPlace('landmark') + '; the people and houses cheer your name.', 'prestige')
                  this.save(society)
                  this.openEmperorActions()
                },
        defendSuccession() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  this.applyStats({ influence: -50 })
                  society.playerPolitics.lastDefendMonth = this.monthKey(state)
                  let auctoritas = this.playerAuctoritasScore(society, state)
                  let success = Math.random() < this.clamp(0.4 + auctoritas / 400, 0.2, 0.9)
                  if (success) {
                    rome.successionPressure = Math.max(0, parseFloat(rome.successionPressure || 0) - 50)
                    rome.successionLaw = 'designation'
                    this.applyStats({ prestige: 10 })
                    this.log(society, 'You face down the factions and keep the succession by designation/adoption.', 'familyTree')
                  } else {
                    rome.successionPressure = Math.max(0, parseFloat(rome.successionPressure || 0) - 15)
                    this.log(society, 'You spend heavily to slow the succession factions, but the pressure remains.', 'familyTree')
                  }
                  this.save(society)
                  this.openEmperorActions()
                },
        debugMakeDictator() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let house = this.playerPoliticsHouse(society, state)
                  rome.government = 'dictatorship'
                  rome.dictatorHouseId = house ? house.id : ''
                  rome.dictatorCharacterId = this.currentCharacterId(state)
                  rome.dictatorTermEnd = this.futureMonthKey(6)
                  society.playerPolitics.wasDictator = true
                  society.playerPolitics.auctoritas = parseFloat(society.playerPolitics.auctoritas || 0) + 50
                  this.save(society)
                  this.log(society, '[debug] You are appointed Dictator.', 'prestige')
                  this.openPolitics()
                  return 'CoR Society: you are now Dictator.'
                },
        debugMakeEmperor() {
                  let society = this.loadForAction()
                  let state = daapi.getState()
                  let rome = this.ensureRomeState(society)
                  let house = this.playerPoliticsHouse(society, state)
                  society.playerPolitics.wasDictator = true
                  rome.government = 'empire'
                  rome.rulerHouseId = house ? house.id : ''
                  rome.rulerCharacterId = this.currentCharacterId(state)
                  rome.everHadEmperor = true
                  rome.successionLaw = 'designation'
                  rome.dictatorHouseId = ''
                  rome.dictatorTermEnd = ''
                  rome.successionPressure = 0
                  this.save(society)
                  this.log(society, '[debug] You are acclaimed Imperator.', 'prestige')
                  this.openPolitics()
                  return 'CoR Society: you are now Imperator (Emperor).'
                },
        simulatePoliticsMonthly(society, state) {
                  try {
                    let rome = this.ensureRomeState(society)
                    let changed = false
                    // REAL standing advantage: supreme office pays and strengthens your house every
                    // month (the imperial fisc / emergency powers), so the rank is materially superior,
                    // not just a label. Emperor > Dictator.
                    let rank = this.playerPoliticalRank(society, state)
                    if (rank) {
                      let playerHouse = this.playerPoliticsHouse(society, state)
                      if (rank === 'emperor') {
                        this.applyStats({ cash: 90, influence: 30, prestige: 8 })
                        if (playerHouse) {
                          playerHouse.power = (playerHouse.power || 0) + 6
                          playerHouse.wealth = (playerHouse.wealth || 0) + 80
                          playerHouse.stability = this.clamp((playerHouse.stability || 50) + 3, 0, 100)
                        }
                      } else {
                        this.applyStats({ cash: 45, influence: 25, prestige: 4 })
                        if (playerHouse) {
                          playerHouse.power = (playerHouse.power || 0) + 3
                          playerHouse.wealth = (playerHouse.wealth || 0) + 40
                        }
                      }
                      changed = true
                    }
                    // Dictator term expiry: the Senate forces a lay-down if you did not seize the purple.
                    if (rome.government === 'dictatorship' && rome.dictatorTermEnd && this.monthKeyReached(rome.dictatorTermEnd, state)) {
                      rome.government = 'republic'
                      rome.dictatorHouseId = ''
                      rome.dictatorCharacterId = ''
                      rome.dictatorTermEnd = ''
                      this.log(society, 'Your dictatorship term ends; the Senate reclaims its authority and Rome returns to the Republic.', 'senator')
                      changed = true
                    }
                    // Captives: deadline release + rival rescue attempts.
                    let keptCaptives = []
                    ;(society.captives || []).forEach((captive) => {
                      if (!captive) return
                      let house = society.houses[captive.houseId]
                      if (captive.until && this.monthKeyReached(captive.until, state)) {
                        if (house) house.relation = this.clamp((house.relation || 0) + 6, -100, 100)
                        this.log(society, captive.name + ' is freed when your hold over them lapses.', 'gift', captive.houseId)
                        changed = true
                        return
                      }
                      if (house && Math.random() < this.clamp(0.05 + (house.power || 0) / 1200, 0.03, 0.25)) {
                        this.log(society, house.name + ' mounts a daring rescue and frees ' + captive.name + '.', 'rivalry', captive.houseId)
                        house.heat = (house.heat || 0) + 2
                        changed = true
                        return
                      }
                      keptCaptives.push(captive)
                    })
                    society.captives = keptCaptives
                    // NPC-vs-NPC land feud flavour (bounded).
                    if (Math.random() < 0.25) {
                      let houses = this.sortedHouses(society).filter((h) => h && !h.isPlayerHouse)
                      if (houses.length >= 2) {
                        let aggressor = houses[this.randomInt(0, Math.min(4, houses.length - 1))]
                        let victim = this.pick(houses.filter((h) => String(h.id) !== String(aggressor.id)))
                        if (aggressor && victim && (aggressor.power || 0) > (victim.power || 0)) {
                          let seized = Math.max(15, Math.round((victim.wealth || 150) * 0.08))
                          victim.wealth = Math.max(0, Math.round((victim.wealth || 0) - seized))
                          aggressor.wealth = (aggressor.wealth || 0) + Math.round(seized * 0.6)
                          victim.relation = this.clamp((victim.relation || 0), -100, 100)
                          this.log(society, aggressor.name + ' seizes ' + this.romanPlace('estate') + ' from ' + victim.name + ' in a property feud.', 'rivalry', victim.id)
                          changed = true
                        }
                      }
                    }
                    // Wars resolve.
                    let keptWars = []
                    ;(rome.wars || []).forEach((war) => {
                      if (!war) return
                      if (war.endMonth && this.monthKeyReached(war.endMonth, state)) {
                        let house = society.houses[war.houseId]
                        if (house) {
                          house.wealth = Math.max(0, Math.round((house.wealth || 0) * 0.8))
                          house.power = Math.max(0, Math.round((house.power || 0) * 0.85))
                          this.log(society, 'The war against ' + house.name + ' ends; they are weakened across their estates.', 'rivalry', war.houseId)
                        }
                        changed = true
                      } else {
                        keptWars.push(war)
                      }
                    })
                    rome.wars = keptWars
                    // Empire succession pressure from rival families.
                    if (rome.government === 'empire') {
                      let rivalPower = this.sortedHouses(society).filter((h) => h && !h.isPlayerHouse && String(h.id) !== String(rome.rulerHouseId)).slice(0, 6)
                        .reduce((sum, h) => sum + Math.max(0, (h.power || 0) - 30), 0)
                      rome.successionPressure = this.clamp(parseFloat(rome.successionPressure || 0) + 2 + rivalPower / 200, 0, 200)
                      if (rome.successionPressure >= 100) {
                        let defendedRecently = society.playerPolitics.lastDefendMonth && this.monthIndex(this.monthKey(state)) - this.monthIndex(society.playerPolitics.lastDefendMonth) < 4
                        if (!defendedRecently) {
                          rome.successionLaw = Math.random() < 0.5 ? 'wealth' : 'power'
                          rome.successionPressure = 60
                          this.log(society, 'The great houses force through a change: imperial succession will now favour the ' + (rome.successionLaw === 'wealth' ? 'wealthiest' : 'strongest') + ' house. Defend your dynasty or lose the throne.', 'familyTree')
                          changed = true
                        }
                      }
                    }
                    if (changed) {
                      this.save(society)
                    }
                  } catch (err) {
                    console.warn(err)
                  }
                }
      })
      window.corSociety._mixinCorSocietyPoliticsVersion = '1.1.319'
    }
  }
}
